SELECT DISTINCT(maker) from Product, PC, Laptop
where Product.maker not IN(
    SELECT DISTINCT(maker) from Product, Printer
    where Product.model = Printer.model
    ) and (Product.model = PC.model or Product.model = Laptop.model)
    ORDER BY maker;