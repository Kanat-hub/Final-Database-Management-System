select min(PC.price) + min(Laptop.price) + min(Printer.price) from PC,Laptop,Printer,Product
where Product.model = PC.model or Product.model = Laptop.model or Product.model = Printer.model;