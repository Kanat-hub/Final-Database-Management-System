select type, count(DISTINCT(maker)) from Product
GROUP by type;