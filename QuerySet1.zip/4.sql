select maker,avg(price) from PC,Product
where PC.model = Product.model and PC.ram > 4
GROUP by maker;
