SELECT maker from Product prod
INNER join Laptop l ON prod.model = l.model
WHERE screen > 15 and price < 1000.0;