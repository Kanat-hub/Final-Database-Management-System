select model from Laptop
where price = (
    Select min(price) from Laptop
    where model in (
        select model
        from Product
        where type = "laptop" and maker in (
            select DISTINCT(maker)
            from Product
            where type = "pc")
            )
                );
