select maker from(
    select maker,count(maker) as cm from Product
    where maker in (
        select distinct(maker) from Product
        where type = "pc" and maker in(
            select distinct(maker) from Product
            where type = "laptop" and maker in(
                select distinct(maker) from Product
                where type = "printer"
                )
                    )
                        )
    GROUP by maker
)
where cm >= 5;