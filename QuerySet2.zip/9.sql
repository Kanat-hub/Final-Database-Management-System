select model,(speed+ram+hd)/price as grade from PC
GROUP by model
ORDER by grade DESC;
