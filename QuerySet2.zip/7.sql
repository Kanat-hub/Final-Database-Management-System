select maker from Product
where model = (
    select model from PC
    where price = (
        select max(price) from PC
        where model in (
            select model
            from Product
            where type = "pc" and maker in (
                select DISTINCT(maker)
                from Product
                where type = "printer")
                ) 
                    )
                        );