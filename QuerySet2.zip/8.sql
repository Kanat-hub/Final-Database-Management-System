select maker 
from (
    select distinct(maker) from Product
    where model in(
        select model from PC
        where speed > 2.0)
        )
where maker in (
        select distinct(maker) from Product
        where model in(
        select model from Laptop 
            where hd > 250)
                ) and maker in (
            select distinct(maker) from Product
            where model in(
                select model from Printer
                where type = "laser")
                    );
